-- actor.entrance
local code_entity = {}
local TAG = "changeGlassesFilter--->>>>>>>"
local TYPE_SHOW_RANDOM = 0
local TYPE_SHOW_ALWAYS_SHOW = 1
local HEAD_UP_MAX = 10   --- > 此值表示该触发换眼镜的操作了
local HEAD_UP_START = 0  --- < 此值表示初始化了
local hasReseted = false    --- 当脸较正地直视屏幕时，表示reseted
local showIndex = 0
local hasChangedWhenLost
local animatingActor
local isInit  = false
-- touch events registers
-- register in your entrance while necessary.
-- e.g :
--  function code_entity:onHolderEntrance(script_ins, actor)
--     self.__script_ins = script_ins
--     self.__holder = actor
-- 	   self:register_gesture_click()
-- 	   self:register_gesture_pinch()
-- end

-- reverse-comment functions like onTouchXXXXEvent that you've called the registered functions.

function code_entity:register_gesture_click()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchClickEvent ~= nil and self.__holder ~= nil then
            self:onTouchClickEvent(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_CLICK)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:register_gesture_move()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchMoveEvent ~= nil and self.__holder ~= nil then
            self:onTouchMoveEvent(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_MOVE)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:register_gesture_move2()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchMove2Event ~= nil and self.__holder ~= nil then
            self:onTouchMove2Event(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_MOVE2)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:register_gesture_pinch()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchPinchEvent ~= nil and self.__holder ~= nil then
            self:onTouchPinchEvent(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_PINCH)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:unregister_gesture_events()
    if self.__gestureListener ~= nil then
        for k, v in pairs(self.__gestureListener) do
            xe.Director:GetInstance():GetEventDispatcher()
                :RemoveEventListener(v)
        end
    end
    self.__gestureListener = nil
end

--查找所有的actor
function code_entity:initElements(world)
    print(TAG .. "initElements")
    nameList = {
        "glasses_01_1",
        "glasses_02_1",
        "glasses_03_1",
        "glasses_04_1"
    }
    self.actorRandom = {}
    for i, v in ipairs(nameList) do 
        self.actorRandom[v] = world:FindActor(v)
        self.actorRandom[v]:SetHidden(true)
    end
    print(TAG, " LEN IS " , table.len(self.actorRandom))
end

function code_entity:initCamera()
    
    local camera = xe.Director:GetInstance():GetWindow():GetViewport():GetAttachCamera()
    local pMatrix = camera:GetProjectionMatrix()

    pMatrix._44 = 1.0
    camera:SetProjectionMatrix(pMatrix)
end


--切换播放动画
function code_entity:playAnim(showingActor,nextActor)
    animatingActor = nextActor
    local rootComponent = nextActor:GetRootComponent()
    print(TAG, "glasses___", "animation_________获取到component：", rootComponent.XType)
    local playList = rootComponent:GetAnimPlayList()
    if playList then

        self.listener = xe.AnimationPlayListener:Create()
        local callback1 = function(param)
            print(TAG, "glasses___", "111111111111111111")
            --rootComponent:GetAnimController():RemoveListener(self.listener)
            --print(TAG, "glasses___", "listener 动画回调移除完成")

        end
        local i = 0
        local callback2 = function(param)
            i = i + 1
 			if i == 5 then
                --playList:Stop()
                showingActor:SetHidden(true)
                animatingActor = nil
                print(TAG, "glasses___", "222222222222222222")
            end
            --rootComponent:GetAnimController():RemoveListener(self.listener)
            --print(TAG, "glasses___", "listener 动画回调移除完成")

        end
        local callback3 = function(param)
            print(TAG, "glasses___", "3333333333333333333333")
            --rootComponent:GetAnimController():RemoveListener(self.listener)
            --print(TAG, "glasses___", "listener 动画回调移除完成")

        end
        self.listener:RegisterHandler(callback1, xe.Handler.XEANIMATIONPLAY_ONETIMEFINISHED_CALLNACK)
        self.listener:RegisterHandler(callback2, xe.Handler.XEANIMATIONPLAY_STEPMOVE_CALLNACK)
        self.listener:RegisterHandler(callback3, xe.Handler.XEANIMATIONPLAY_PLAYSTATECHANGE_CALLNACK)
        playList:AddListener(self.listener)
        playList:PlayItem(0);
        print(TAG, "glasses___", "animation_________播放动画")
    end
end

function code_entity:updatePlayStatus(face)
    --代表有人脸数据，更新状态
    if face then
 
        index = 0
        local showingActor 
        local nextActor

        for i, v in pairs(self.actorRandom) do
            index = index + 1
            if index == (showIndex % table.len(self.actorRandom) + 1) then
                v:SetHidden(false)
                -- v:ApplyWorldTransform(matrix)
                showingActor = v
            end
            if index == ((showIndex + 1) % table.len(self.actorRandom) + 1) then
                nextActor = v
            end
        end

        --正脸初始化
        if face.vEulerAngle.x < HEAD_UP_START and not hasReseted then 
            hasReseted = true
        end
        ---抬头标准
        if hasReseted then
            if face.vEulerAngle.x > HEAD_UP_MAX then
                hasReseted = false
                showIndex = showIndex + 1
                self:playAnim(showingActor, nextActor)
            end
        end
    else--无人脸，全部消失
        for i, v in pairs(self.actorRandom) do
            v:SetHidden(true)
        end
    end

end

function code_entity:checkRunningStatus()
    local envBridge = XEMagicCore.GetEnvBridge()
    local firstFace = nil
    if envBridge ~= nil then
        local faceList = envBridge:GetFaceList()
        if nil ~= faceList and #faceList >= 1 then
            firstFace = faceList[1]
        end
    else
        print(TAG, "GetDecorationEnvBridge = nil")
    end
    self:updatePlayStatus(firstFace)
end
function code_entity:initAll(actor)
    
    if isInit == false then

        -- self:initCamera()
        self:initElements(actor:GetOwner())
        isInit = true
    end
    -- body
end
-- delay call
-- this function will be called once when the binding holder is ready to work.
function code_entity:onHolderEntrance(script_ins, actor)
    self.__script_ins = script_ins
    self.__holder = actor
    -- add something new here.
end

-- this function will be called once when the binding holder is ready to release.
function code_entity:onHolderRelease(actor)
    self.__holder = nil
    self:unregister_gesture_events()
    -- add something new here.
end

-- this function will be called each tick after the ticking of the holder.
function code_entity:onHolderTick(actor, interval)
    -- add something new here.
    self:initAll(actor)
    self:checkRunningStatus()
end

-- this function will be called each tick after the rendering of the holder.
function code_entity:onHolderRender(actor, viewport)
    -- add something new here.
end

-- this function will return the binding holder
function code_entity:holder()
    return self.__holder -- maybe nil, need to be verify when you use it.
end

-- this function will return the binding script_ins
function code_entity:script_ins()
    return self.__script_ins -- maybe nil, need to be verify when you use it.
end

-- add other logics as you want here.
-- This script will run once. code_entity will be built.
-- call something other executable here. 
print("こんにちは、じゃ、まだね。")
-- cannot call the cpp side function immediately.
-- the return value should be A table.
return code_entity
