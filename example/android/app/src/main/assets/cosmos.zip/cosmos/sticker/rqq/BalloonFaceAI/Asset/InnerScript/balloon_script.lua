-- actor.entrance
local code_entity = {}

-- touch events registers
-- register in your entrance while necessary.
-- e.g :
--  function code_entity:onHolderEntrance(script_ins, actor)
--     self.__script_ins = script_ins
--     self.__holder = actor
-- 	   self:register_gesture_click()
-- 	   self:register_gesture_pinch()
-- end

-- reverse-comment functions like onTouchXXXXEvent that you've called the registered functions.

function code_entity:register_gesture_click()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchClickEvent ~= nil and self.__holder ~= nil then
            self:onTouchClickEvent(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_CLICK)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:register_gesture_move()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchMoveEvent ~= nil and self.__holder ~= nil then
            self:onTouchMoveEvent(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_MOVE)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:register_gesture_move2()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchMove2Event ~= nil and self.__holder ~= nil then
            self:onTouchMove2Event(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_MOVE2)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:register_gesture_pinch()
    local gestureListener = xe.GestureEventListenerV1:Create()
    if self.__gestureListener == nil then self.__gestureListener = {} end
    table.insert(self.__gestureListener, gestureListener)
    gestureListener:RegisterHandler(function(sender, param)
        if self.onTouchPinchEvent ~= nil and self.__holder ~= nil then
            self:onTouchPinchEvent(self.__holder, param)
        end
    end, xe.Handler.EVENT_GESTURE_PINCH)
    xe.Director:GetInstance():GetEventDispatcher():SetEnabled(true)
    xe.Director:GetInstance():GetEventDispatcher():AddEventListener(
        gestureListener, nil)
end

function code_entity:unregister_gesture_events()
    if self.__gestureListener ~= nil then
        for k, v in pairs(self.__gestureListener) do
            xe.Director:GetInstance():GetEventDispatcher()
                :RemoveEventListener(v)
        end
    end
    self.__gestureListener = nil
end

-- delay call
-- this function will be called once when the binding holder is ready to work.
function code_entity:onHolderEntrance(script_ins, actor)
    self.__script_ins = script_ins
    self.__holder = actor
    -- add something new here.
end

-- this function will be called once when the binding holder is ready to release.
function code_entity:onHolderRelease(actor)
    self.__holder = nil
    self:unregister_gesture_events()
    -- add something new here.
end

-- this function will be called each tick after the ticking of the holder.
function code_entity:onHolderTick(actor, interval)
    -- add something new here.
	if self.isLoadSoftske == nil then 
		self.isLoadSoftske = true
		self.__holder:GetRootComponent():LoadSoftSkeleton("Asset/07a5337471c00000/Balloon@skin+/balloon.softske")
	end
end

-- this function will be called each tick after the rendering of the holder.
function code_entity:onHolderRender(actor, viewport)
    -- add something new here.
end

-- this function will return the binding holder
function code_entity:holder()
    return self.__holder -- maybe nil, need to be verify when you use it.
end

-- this function will return the binding script_ins
function code_entity:script_ins()
    return self.__script_ins -- maybe nil, need to be verify when you use it.
end

-- touch events(inject logics here)
-- function code_entity:onTouchClickEvent(actor, click_param)
--     -- add something new here.
--     if click_param.eState == GestureClickParam.Raised then
--         -- do anything that you want.
--     end
-- end

-- --single finger move
-- function code_entity:onTouchMoveEvent(actor, move_param)
-- -- add something new here.
-- end

-- --double fingers move via same direction
-- function code_entity:onTouchMove2Event(actor, move2_param)
-- -- add something new here.
-- end

-- --double fingers move via different directions
-- function code_entity:onTouchPinchEvent(actor, pinch_param)
-- -- add something new here.
-- end

-- --indicated that the native events.  ids, posX, posY is array.
-- function code_entity:onNativeTouchesBeginEvent(actor, number, ids, posX, posY)
-- -- add something new here.
-- end

-- function code_entity:onNativeTouchesMoveEvent(actor, number, ids, posX, posY)
-- -- add something new here.
-- end

-- function code_entity:onNativeTouchesEndEvent(actor, number, ids, posX, posY)
-- -- add something new here.
-- end

-- add other logics as you want here.
-- This script will run once. code_entity will be built.
-- call something other executable here. 
print("こんにちは、じゃ、まだね。")
-- cannot call the cpp side function immediately.
-- the return value should be A table.
return code_entity
